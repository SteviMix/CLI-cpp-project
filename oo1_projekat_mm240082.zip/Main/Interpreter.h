//
// Created by Mihajlo Matovic on 7. 1. 2026..
//

#ifndef INTERPRETER_H
#define INTERPRETER_H

#include <memory>
#include <string>
#include "../AbstractClasses/InputStream.h"
#include "../AbstractClasses/OutputStream.h"

// Main class for running the interpreter.
class Interpreter {
public:
    ~Interpreter() = default;

    Interpreter(std::shared_ptr<InputStream> in,
        std::shared_ptr<OutputStream> out,
        std::shared_ptr<OutputStream> err)
            :   input(std::move(in))
            ,   output(std::move(out))
            ,   errorOutput(std::move(err)) {}

    // Class method that starts the execution of the interpreter.
    void run();
private:
    std::string prompt = "$";

    std::shared_ptr<InputStream> input;
    std::shared_ptr<OutputStream> output;
    std::shared_ptr<OutputStream> errorOutput;
};



#endif //INTERPRETER_H
