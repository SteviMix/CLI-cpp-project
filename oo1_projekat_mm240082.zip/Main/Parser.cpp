//
// Created by Mihajlo Matovic on 3. 1. 2026..
//

#include "Parser.h"
#include "../Commands/EchoCommand.h"
#include "../Commands/TimeCommand.h"
#include "../Commands/DateCommand.h"
#include "../Commands/TouchCommand.h"
#include "../Commands/WCCommand.h"
std::unique_ptr<Command> Parser::parseCommand(const std::string& name) {
    if (name == "echo") {
        return std::make_unique<EchoCommand>();
    }
    if (name == "time") {
        return std::make_unique<TimeCommand>();
    }
    if (name == "date") {
        return std::make_unique<DateCommand>();
    }
    if (name == "touch") {
        return std::make_unique<TouchCommand>();
    }
    if (name == "wc") {
        return std::make_unique<WCCommand>();
    }
    return nullptr;
}

