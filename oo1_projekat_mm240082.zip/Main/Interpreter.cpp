//
// Created by Mihajlo Matovic on 7. 1. 2026..
//

#include <string>
#include <iostream>
#include "Interpreter.h"
#include "Reader.h"
#include "Parser.h"
#include "../AbstractClasses/CommandError.h"

void Interpreter::run() {
    while (true) {

        // Writing the command prompt.
        output->writeString(prompt + " ");

        // Reading a line from the input stream.
        std::string line;
        if (!input->readLine(line)) {
            break;
        }

        // Parsing the line into tokens.
        std::vector<Token> tokens = Reader::read(line);
        if (tokens.empty()) continue;

        // Creates the specific command.
        std::string cmdName = tokens[0].string;

        auto command = Parser::parseCommand(cmdName);

        // Executing command logic.
        if (command != nullptr) {
            std::vector<Token> args;

            if (tokens.size() > 1) {
                args.assign(tokens.begin() + 1, tokens.end());
            }
            try {
                command->execute(args, input, output, errorOutput);
            }
            // Catching command errors.
            catch (const CommandError& e) {
                errorOutput->writeString(e.what());
                errorOutput->writeString("\n");
            }
            catch (...) {
                errorOutput->writeString("Unknown error\n");
            }
            if (std::cin.eof()) {
                std::cin.clear();
            }
        }
    }
}
