//
// Created by Mihajlo Matovic on 3. 1. 2026..
//

#ifndef PARSER_H
#define PARSER_H
#include <string>
#include <vector>
#include "../AbstractClasses/Command.h"
// Class for creating commands.
class Parser {
public:

    // Static method that returns a unique pointer to a command.
    static std::unique_ptr<Command> parseCommand(const std::string& name);
};



#endif //PARSER_H
