//
// Created by Mihajlo Matovic on 3. 1. 2026..
//

#include "Reader.h"

int Reader::maxLineLength = 512;

std::vector<Token> Reader::read(const std::string& line) {
    std::vector<Token> tokens;
    std::string currToken;
    bool inString = false;
    bool inQuotes = false;

    int len = 0;
    for (char c : line) {
        len ++;
        if (len > maxLineLength) {
            break;
        }
        if (c == '"') {
            inString = !inString;
            inQuotes = true;
        }
        else if (std::isspace(c) && !inString) {
            if (!currToken.empty()) {
                tokens.push_back({currToken, inQuotes});
                currToken.clear();
                inQuotes = false;
            }
        }
        else {
            currToken += c;
        }
    }
    if (!currToken.empty()) {
        tokens.push_back({currToken, inQuotes});
    }
    return tokens;
}