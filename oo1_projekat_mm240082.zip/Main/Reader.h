//
// Created by Mihajlo Matovic on 3. 1. 2026..
//

#ifndef READER_H
#define READER_H
#include <vector>
#include <string>

#include "../Types.h"

// Class for reading the input.
class Reader {
public:
    // Static method for reading the input.
    static std::vector<Token> read(const std::string& line);

private:
    static int maxLineLength;
};



#endif //READER_H
