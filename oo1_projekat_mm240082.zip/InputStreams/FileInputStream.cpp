//
// Created by Mihajlo Matovic on 10. 1. 2026..
//

#include "FileInputStream.h"


FileInputStream::FileInputStream(const std::string& filename) {
    file.open(filename);
}


bool FileInputStream::readChar(char& c) {
    if (file.get(c)) {
        return true;
    }
    return false;
}

bool FileInputStream::readLine(std::string& line) {
    if (std::getline(file, line)) {
        return true;
    }
    return false;
}

bool FileInputStream::eof() const {
    return file.eof();
}

bool FileInputStream::isOpen() const {
    return file.is_open();
}