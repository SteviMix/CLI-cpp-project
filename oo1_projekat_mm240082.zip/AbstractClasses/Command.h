//
// Created by Mihajlo Matovic on 12. 12. 2025..
//

#ifndef COMMAND_H
#define COMMAND_H
#include <vector>
#include <memory>
#include "../Types.h"

// Forward declarations.
class InputStream;
class OutputStream;
class CommandError;
// Abstract base class for all commands.
// Every command reads from InputStream, writes in OutputStream and handles errors.
class Command {
public:
    virtual ~Command() = default;

    // Accepts arguments and executes the function. Throws CommandError on failure.
    virtual void execute(
        const std::vector<Token>& args,
        std::shared_ptr<InputStream> input,
        std::shared_ptr<OutputStream> output,
        std::shared_ptr<OutputStream> errorOutput
        ) = 0;

};




#endif //COMMAND_H
