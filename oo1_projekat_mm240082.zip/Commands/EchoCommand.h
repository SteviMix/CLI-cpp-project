//
// Created by Mihajlo Matovic on 13. 12. 2025..
//

#ifndef ECHOCOMMAND_H
#define ECHOCOMMAND_H

#include "../Types.h"
#include "../AbstractClasses/Command.h"

// Class for the Echo command.
// Writes characters from it's input stream to it's output stream.
class EchoCommand: public Command{
public:
    EchoCommand() = default;

    // Overriding base class method.
    // Implementing specific command execution logic
    void execute(
        const std::vector<Token> &args,
        std::shared_ptr<InputStream> input,
        std::shared_ptr<OutputStream> output,
        std::shared_ptr<OutputStream> errorOutput) override;
};



#endif //ECHOCOMMAND_H
