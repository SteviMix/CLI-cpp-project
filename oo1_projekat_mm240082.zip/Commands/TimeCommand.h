//
// Created by Mihajlo Matovic on 10. 1. 2026..
//

#ifndef TIMECOMMAND_H
#define TIMECOMMAND_H

#include "../AbstractClasses/Command.h"

// Class for the Time command.
// Writes the system time to it's output stream.
class TimeCommand : public Command {
public:
    TimeCommand() = default;

    void execute(
        const std::vector<Token> &args,
        std::shared_ptr<InputStream> input,
        std::shared_ptr<OutputStream> output,
        std::shared_ptr<OutputStream> errorOutput) override;
};



#endif //TIMECOMMAND_H
