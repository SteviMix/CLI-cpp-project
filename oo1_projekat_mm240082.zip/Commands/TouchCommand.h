//
// Created by Mihajlo Matovic on 10. 1. 2026..
//

#ifndef TOUCHCOMMAND_H
#define TOUCHCOMMAND_H


#include "../AbstractClasses/Command.h"

// Class for the Touch command.
// Creates a file with the given filename. Throws error if file already exists.
class TouchCommand : public Command {
public:
    TouchCommand() = default;

    void execute(const std::vector<Token> &args,
        std::shared_ptr<InputStream> input,
        std::shared_ptr<OutputStream> output,
        std::shared_ptr<OutputStream> errorOutput) override;
};



#endif //TOUCHCOMMAND_H
