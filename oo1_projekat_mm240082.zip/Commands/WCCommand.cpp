//
// Created by Mihajlo Matovic on 10. 1. 2026..
//

#include "WCCommand.h"

#include <iostream>

#include "../AbstractClasses/CommandError.h"
#include "../AbstractClasses/InputStream.h"
#include "../AbstractClasses/OutputStream.h"
#include "../InputStreams/ConsoleInputStream.h"
#include "../InputStreams/StringInputStream.h"
#include "../InputStreams/FileInputStream.h"
void WCCommand::execute(
        const std::vector<Token> &args,
        std::shared_ptr<InputStream> input,
        std::shared_ptr<OutputStream> output,
        std::shared_ptr<OutputStream> errorOutput
        ) {

        // Checks the number of arguments.
        if (args.empty()) {
                throw CommandError(ErrorType::Execution, "Missing arguments");
        }
        if (args.size() > 2) {
                throw CommandError(ErrorType::Execution, "Too many arguments");
        }

        // Creates the corresponding input stream.
        std::shared_ptr<InputStream> src;
        if (args.size() == 2) {
                if (args[1].inQuotes) {
                        src = std::make_shared<StringInputStream>(args[1].string);
                }
                else {
                        auto fileSrc = std::make_shared<FileInputStream>(args[1].string);

                        if (!fileSrc->isOpen()) {
                                throw CommandError(ErrorType::OS,"File can't be opened: "+args[1].string);
                        }

                        src = fileSrc;
                }
        }
        if (args.size() == 1) {
                src = std::make_shared<ConsoleInputStream>();
        }

        // Checks the command option.
        size_t cnt;
        if (args[0].string == "-c" ) {
                cnt = countChars(src);
        }
        else if (args[0].string == "-w" ) {
                cnt = countWords(src);
        }
        else {
                throw CommandError(ErrorType::Execution, "Unknown argument: "+args[0].string);
        }
        output->writeString(std::to_string(cnt) + "\n");
}


std::size_t WCCommand::countWords(std::shared_ptr<InputStream> input) {
        char c;
        int cnt = 0;
        bool isWord = false;
        while (input->readChar(c)) {
                if (std::isspace(c)) {
                        if (isWord) {
                                cnt++;
                                isWord = false;
                        }
                }
                else {isWord = true;}
        }
        if (isWord) {cnt++;}
        return cnt;
}

std::size_t WCCommand::countChars(std::shared_ptr<InputStream> input) {
        char c;
        int cnt = 0;
        while (input->readChar(c)) {
                cnt++;
        }
        return cnt;
}