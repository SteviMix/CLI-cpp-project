//
// Created by Mihajlo Matovic on 10. 1. 2026..
//

#include <fstream>

#include "TouchCommand.h"
#include "../AbstractClasses/CommandError.h"


void TouchCommand::execute(
    const std::vector<Token> &args,
    std::shared_ptr<InputStream> input,
    std::shared_ptr<OutputStream> output,
    std::shared_ptr<OutputStream> errorOutput
    ) {

    // Checks the arguments.
    if (args.empty()) {
        throw CommandError(ErrorType::Execution, "Missing filename\n");
    }
    if (args.size() != 1) {
        throw CommandError(ErrorType::Execution, "Touch command must have 1 argument");
    }

    // Opens the file with the given filename.
    // Throws error if the file already exists or if it can't be opened.
    std::string filename = args[0].string;
    std::ifstream file_check(filename);
    if (file_check.is_open()) {
        file_check.close();
        throw CommandError(ErrorType::Execution, "File already exists");
    }
    std::ofstream file(filename);
    if (!file.is_open()) {
        throw CommandError(ErrorType::OS, "File could not be opened");
    }
    file.close();
}
