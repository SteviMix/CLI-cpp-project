//
// Created by Mihajlo Matovic on 10. 1. 2026..
//

#include <ctime>

#include "DateCommand.h"
#include "../AbstractClasses/CommandError.h"
#include "../AbstractClasses/OutputStream.h"


void DateCommand::execute(
    const std::vector<Token> &args,
    std::shared_ptr<InputStream> input,
    std::shared_ptr<OutputStream> output,
    std::shared_ptr<OutputStream> errorOutput
    ) {

    // Checks for arguments.
    if (!args.empty()) {
        throw CommandError(ErrorType::Execution, "Date command must have 0 arguments");
    }

    // Gets the system date.
    std::time_t currentTime = std::time(nullptr);
    std::tm* date = std::localtime(&currentTime);

    // Writes the date to the output stream.
    char buffer[11];
    std::strftime(buffer, sizeof(buffer), "%d.%m.%Y", date);
    output->writeString(std::string(buffer)+"\n");
}
