//
// Created by Mihajlo Matovic on 13. 12. 2025..
//

#include "EchoCommand.h"

#include <complex>
#include <iostream>

#include "../AbstractClasses/InputStream.h"
#include "../AbstractClasses/OutputStream.h"
#include "../InputStreams/StringInputStream.h"
#include "../InputStreams/ConsoleInputStream.h"
#include "../InputStreams/FileInputStream.h"
#include "../AbstractClasses/CommandError.h"

void EchoCommand::execute(
    const std::vector<Token> &args,
    std::shared_ptr<InputStream> input,
    std::shared_ptr<OutputStream> output,
    std::shared_ptr<OutputStream> errorOutput
    ){
    std::shared_ptr<InputStream> src;

    // Checks the command arguments and creates the corresponding input stream.
    if (args.empty()) {
        src = std::make_shared<ConsoleInputStream>();
    }
    else if (args.size() > 1) {
        throw CommandError(ErrorType::Execution, "Too many arguments, echo can have 0 or 1 arguments");
    }
    else {
        if (args[0].inQuotes) {
            src = std::make_shared<StringInputStream>(args[0].string);
        }
        else {
            auto fileSrc = std::make_shared<FileInputStream>(args[0].string);

            if (!fileSrc->isOpen()) {
                throw CommandError(ErrorType::OS,"File can't be opened: "+args[0].string);
            }
            src = fileSrc;
        }
    }

    // Writes the characters to the output stream.
    char c;
    std::string str;
    while (src->readChar(c)) {
        str += c;
    }
    output->writeString(str);
    output->writeChar('\n');
}
