//
// Created by Mihajlo Matovic on 10. 1. 2026..
//
#include <ctime>
#include <iomanip>
#include <chrono>
#include <sstream>

#include "TimeCommand.h"
#include "../AbstractClasses/CommandError.h"
#include "../AbstractClasses/OutputStream.h"

void TimeCommand::execute(
    const std::vector<Token> &args,
    std::shared_ptr<InputStream> input,
    std::shared_ptr<OutputStream> output,
    std::shared_ptr<OutputStream> errorOutput
    ){

    // Checks for arguments.
    if (!args.empty()) {
        throw CommandError(ErrorType::Execution, "Time command must have 0 arguments");
    }

    // Gets the system time.
    auto time = std::chrono::system_clock::now();
    std::time_t t = std::chrono::system_clock::to_time_t(time);

    // Writes the time to the output stream.
    std::tm *tm = std::localtime(&t);
    std::ostringstream oss;

    oss << std::put_time(tm, "%H:%M:%S");
    output->writeString(oss.str()+"\n");
}
