//
// Created by Mihajlo Matovic on 10. 1. 2026..
//

#ifndef DATECOMMAND_H
#define DATECOMMAND_H

#include "../AbstractClasses/Command.h"


// Class for the Date command.
// Writes the system date to it's output stream.
class DateCommand : public Command{
public:
    DateCommand() = default;

    void execute(const std::vector<Token> &args,
        std::shared_ptr<InputStream> input,
        std::shared_ptr<OutputStream> output,
        std::shared_ptr<OutputStream> errorOutput) override;
};



#endif //DATECOMMAND_H
